# Jarvis v2 (Android) - Vosk wake word + WhatsApp + Reels control
1. Repo me push/upload karo, Actions -> "Build APK" chalao, Artifacts se jarvis-apk download karo.
2. App kholo: [1] PERMISSIONS, [2] OVERLAY, [3] ACCESSIBILITY (Jarvis ON), [4] BATTERY.
3. Beech wale dil (heart) ko dabao: ON/OFF. Dil dhadakta hai to Jarvis sun raha hai.
4. [?] COMMANDS dabao to saari commands dikhengi.

WhatsApp:  "Jarvis, whatsapp pe Rahul ko hello bhej"
           "Jarvis, Rahul ki chat me I don't know likh aur send kar de"
Reels:     "next", "previous", "like", "pause", "auto scroll on/off", "instagram reels khol", "youtube shorts khol"
Phone:     "swipe up/down", "back", "home", "recents", "screenshot", "volume up/down"

Note: Contact ka 10 digit number ho to country code 91 (India) lagta hai. Badalna ho to Commands.kt me DEFAULT_CC.

Naam: app me "USER NAME" box me apna naam likho. Jarvis bulane par bolega "Main Jarvis hoon <naam>, bolo kya kaam hai" aur har jawab naam leke dega.
