package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.view.KeyEvent
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    // Contact ka number 10 digit ho to WhatsApp number banane ke liye ye country code lagega (India = 91)
    private const val DEFAULT_CC = "91"

    private val ALIAS = linkedMapOf(
        "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "वाट्सएप" to "whatsapp", "वाट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
        "वाट्सअप" to "whatsapp", "वॉट्सएप" to "whatsapp", "व्हाट्स एप" to "whatsapp",
        "whats app" to "whatsapp", "what's app" to "whatsapp",
        "फेसबुक" to "facebook", "यूट्यूब" to "youtube", "गूगल" to "google", "जीमेल" to "gmail",
        "स्पॉटिफाई" to "spotify", "कैमरा" to "camera",
        "रील्स" to "reels", "रिल्स" to "reels", "रील" to "reels", "रिल" to "reels",
        "शॉर्ट्स" to "shorts", "शार्ट्स" to "shorts", "शॉर्ट" to "shorts"
    )

    // Devanagari bolne ke words ko Latin keyword me badalne ke liye (sirf command samajhne ke liye)
    private val DEV = mapOf(
        "agla" to "next", "agli" to "next", "agle" to "next", "अगला" to "next", "अगली" to "next",
        "अगले" to "next", "नेक्स्ट" to "next", "स्किप" to "next", "skip" to "next",
        "pichla" to "prev", "pichli" to "prev", "pichle" to "prev", "पिछला" to "prev", "पिछली" to "prev",
        "पिछले" to "prev", "प्रीवियस" to "prev", "previous" to "prev",
        "ऊपर" to "upar", "नीचे" to "neeche", "अप" to "up", "डाउन" to "down",
        "स्वाइप" to "swipe", "स्वाईप" to "swipe", "स्क्रॉल" to "scroll", "स्क्रोल" to "scroll",
        "लाइक" to "like", "पॉज" to "pause", "रुको" to "ruko", "रुक" to "ruko",
        "वापस" to "back", "पीछे" to "back", "बैक" to "back", "peeche" to "back", "wapas" to "back",
        "होम" to "home", "स्क्रीनशॉट" to "screenshot", "नोटिफिकेशन" to "notification",
        "वॉल्यूम" to "volume", "वॉल्युम" to "volume", "आवाज" to "volume", "आवाज़" to "volume",
        "बढ़ा" to "inc", "बढ़ाओ" to "inc", "बढाओ" to "inc", "ज्यादा" to "inc", "ज़्यादा" to "inc",
        "कम" to "dec", "घटा" to "dec", "घटाओ" to "dec", "म्यूट" to "mute",
        "ऑटो" to "auto", "बंद" to "off", "चालू" to "on", "रीसेंट" to "recent",
        "चैट" to "chat", "में" to "me", "मे" to "me", "मैं" to "me", "की" to "ki", "के" to "ke",
        "का" to "ka", "को" to "ko", "लिख" to "likh", "लिखो" to "likh", "लिखना" to "likh",
        "भेज" to "bhej", "भेजो" to "bhej", "भेजना" to "bhej", "भेजें" to "bhej", "भेजे" to "bhej",
        "सेंड" to "send", "सेन्ड" to "send", "और" to "aur", "कर" to "kar", "करो" to "karo",
        "दे" to "de", "दो" to "do", "खोलो" to "kholo", "खोल" to "khol", "चला" to "chala", "चलाओ" to "chalao"
    )

    private val FILL = setOf(
        "jarvis", "जार्विस", "जारविस", "please", "youtube", "you", "tube", "pe", "par", "ko", "ka", "ki", "ke",
        "kar", "karo", "kr", "do", "de", "chala", "chalao", "play", "search", "kholo", "khol", "open",
        "call", "phone", "subscribe", "laga", "lagao", "sunao", "dikhao", "hai", "kya", "batao", "bata",
        "channel", "video", "song", "gana", "gaana", "on", "the", "to", "a",
        "पे", "पर", "को", "का", "की", "के", "कर", "करो", "दो", "दे", "चला", "चलाओ", "खोलो", "खोल", "कॉल",
        "फोन", "लगा", "लगाओ", "सुनाओ", "दिखाओ", "है", "क्या", "बताओ", "सब्सक्राइब", "चैनल", "वीडियो",
        "गाना", "गाने", "प्ले", "सर्च"
    )

    private val OPEN_W = setOf("open", "khol", "kholo", "chala", "chalao", "chalu", "start", "dikhao", "lagao", "laga")
    private val UP_W = setOf("up", "upar")
    private val DOWN_W = setOf("down", "neeche", "niche")
    private val LEFT_W = setOf("left", "baya", "bayen")
    private val RIGHT_W = setOf("right", "daya", "dayen")
    private val MUSIC_W = setOf("song", "music", "gana", "gaana", "gaane", "gane")
    private val INC_W = setOf("up", "upar", "inc", "badha", "badhao", "zyada", "jyada", "increase", "more", "high")
    private val DEC_W = setOf("down", "neeche", "dec", "kam", "ghata", "ghatao", "decrease", "less", "low")
    private val BUSY_W = setOf("play", "chala", "chalao", "search", "subscribe", "call", "youtube")

    private val WA_PLACE = setOf("me", "mein", "par", "pe", "m", "se")
    private val SEND_W = setOf("send", "bhej", "bhejo", "bhejna", "bhejde", "bhejdo")
    private val WA_VERB = SEND_W + setOf("likh", "likho", "likhna", "type", "text", "likhde", "likhdo")
    private val TAIL = WA_VERB + setOf(
        "de", "do", "dena", "kar", "karo", "kr", "krdo", "kardo", "karna", "aur", "and", "phir", "fir",
        "bhi", "please", "plz", "na", "dijiye", "message", "msg", "jaldi"
    )
    private val WA_LEAD = setOf(
        "whatsapp", "pe", "par", "me", "mein", "on", "open", "khol", "kholo", "kar", "karo", "aur", "and",
        "phir", "fir", "jarvis", "send", "bhej", "message", "msg", "text", "likh", "ko", "chat", "ki", "ke",
        "ka", "kr", "se"
    )
    private val NAME_TAIL = setOf("ki", "ke", "ka")

    private val WAKES = listOf("jarvis", "जार्विस", "जारविस", "जार्विश", "जारवीस", "जार्वीस")

    private fun cutWake(s: String): String {
        var best = -1
        var len = 0
        for (w in WAKES) {
            val i = s.indexOf(w, ignoreCase = true)
            if (i >= 0 && (best < 0 || i < best)) { best = i; len = w.length }
        }
        return if (best >= 0) s.substring(best + len) else s
    }

    private fun clean(t: String) =
        t.split(Regex("\\s+")).filter { it.lowercase() !in FILL }.joinToString(" ").trim()

    private fun go(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {}
    }

    private fun yt(ctx: Context, q: String, channels: Boolean) {
        val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8") +
                (if (channels) "&sp=EgIQAg%253D%253D" else "")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")
        go(ctx, i)
    }

    // ---------- Contacts (Hindi/English naam dono se match) ----------

    private val SKEL = mapOf(
        'क' to 'k', 'ख' to 'k', 'ग' to 'g', 'घ' to 'g', 'ङ' to 'n', 'च' to 'c', 'छ' to 'c',
        'ज' to 'j', 'झ' to 'j', 'ञ' to 'n', 'ट' to 't', 'ठ' to 't', 'ड' to 'd', 'ढ' to 'd', 'ण' to 'n',
        'त' to 't', 'थ' to 't', 'द' to 'd', 'ध' to 'd', 'न' to 'n', 'प' to 'p', 'फ' to 'f', 'ब' to 'b',
        'भ' to 'b', 'म' to 'm', 'र' to 'r', 'ल' to 'l', 'ळ' to 'l', 'व' to 'v', 'श' to 's', 'ष' to 's', 'स' to 's'
    )

    // Naam ka "skeleton": vowels hata ke consonants. "राहुल" aur "Rahul" dono -> "rl"
    private fun skeleton(s: String): String {
        val low = s.lowercase().replace("ph", "f")
        val sb = StringBuilder()
        for (ch in low) {
            val c: Char? = SKEL[ch] ?: when (ch) {
                'q' -> 'k'
                'z' -> 'j'
                'w' -> 'v'
                in 'a'..'z' -> if (ch in "aeiouyh") null else ch
                else -> null
            }
            if (c != null && (sb.isEmpty() || sb.last() != c)) sb.append(c)
        }
        return sb.toString()
    }

    private fun findContact(ctx: Context, spoken: String): Pair<String, String>? {
        val name = spoken.trim()
        if (name.isEmpty()) return null
        val list = ArrayList<Pair<String, String>>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use {
                while (it.moveToNext()) {
                    val dn = it.getString(0) ?: continue
                    val nu = it.getString(1) ?: continue
                    list.add(dn to nu)
                }
            }
        } catch (e: Exception) { return null }
        if (list.isEmpty()) return null

        val q = name.lowercase()
        val qs = skeleton(q)
        var best: Pair<String, String>? = null
        var bestScore = 0
        for (c in list) {
            val d = c.first.lowercase()
            var sc = 0
            if (d == q) sc = 100
            else if (d.startsWith(q)) sc = 80
            else if (d.contains(q)) sc = 60
            else {
                val ds = skeleton(d)
                if (qs.length >= 2) {
                    if (ds == qs) sc = 70
                    else if (ds.startsWith(qs)) sc = 50
                    else if (ds.contains(qs)) sc = 30
                } else if (qs.isNotEmpty() && ds == qs) sc = 20
            }
            if (sc > bestScore) { bestScore = sc; best = c }
        }
        if (best == null && name.contains(" ")) return findContact(ctx, name.split(" ")[0])
        return best
    }

    private fun waNumber(raw: String): String {
        val d = raw.filter { it.isDigit() }
        return when {
            raw.trim().startsWith("+") -> d
            d.length == 10 -> DEFAULT_CC + d
            d.length == 11 && d.startsWith("0") -> DEFAULT_CC + d.substring(1)
            else -> d
        }
    }

    private fun findApp(ctx: Context, name: String): Intent? {
        val pm = ctx.packageManager
        val n = name.lowercase()
        if (n.length < 2) return null
        val apps = pm.getInstalledApplications(0)
        for (a in apps) {
            if (pm.getApplicationLabel(a).toString().lowercase() == n) {
                pm.getLaunchIntentForPackage(a.packageName)?.let { return it }
            }
        }
        for (a in apps) {
            val label = pm.getApplicationLabel(a).toString().lowercase()
            if (label.length >= 3 && (label.contains(n) || n.contains(label))) {
                pm.getLaunchIntentForPackage(a.packageName)?.let { return it }
            }
        }
        return null
    }

    // ---------- WhatsApp ----------

    private class WaMsg(val name: String, val msg: String, val send: Boolean)

    private fun parseWa(o: List<String>, n: List<String>): WaMsg? {
        val chat = n.indexOf("chat")
        if (chat > 0) {
            var s = chat + 1
            while (s < n.size && n[s] in WA_PLACE) s++
            waBuild(o, n, chat, s)?.let { return it }
        }
        val ko = n.indexOf("ko")
        if (ko > 0) return waBuild(o, n, ko, ko + 1)
        return null
    }

    private fun waBuild(o: List<String>, n: List<String>, nameEnd: Int, msgStart: Int): WaMsg? {
        var a = 0
        while (a < nameEnd && n[a] in WA_LEAD) a++
        var b = nameEnd
        while (b > a && n[b - 1] in NAME_TAIL) b--
        if (a >= b) return null
        val name = o.subList(a, b).joinToString(" ")

        var m = msgStart
        if (m < n.size && n[m] == "whatsapp") {
            m++
            while (m < n.size && n[m] in WA_PLACE) m++
        }
        var send = false
        var k = m
        while (k < n.size && (n[k] == "message" || n[k] == "msg" || n[k] == "text")) k++
        if (k < n.size && n[k] in WA_VERB) {
            while (k < n.size && n[k] in TAIL) { if (n[k] in SEND_W) send = true; k++ }
            m = k
        }
        var e = n.size
        while (e > m && n[e - 1] in TAIL) e--
        for (i in e until n.size) if (n[i] in SEND_W) send = true
        if (m >= e) return null
        return WaMsg(name, o.subList(m, e).joinToString(" "), send)
    }

    private fun whatsapp(ctx: Context, o: List<String>, n: List<String>, say: (String) -> Unit): Boolean {
        val p = parseWa(o, n) ?: return false
        val c = findContact(ctx, p.name)
        if (c == null) { say("${p.name} naam ka contact nahi mila"); return true }
        val uri = Uri.parse("whatsapp://send?phone=" + waNumber(c.second) + "&text=" + Uri.encode(p.msg))
        var ok = false
        for (pk in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val i = Intent(Intent.ACTION_VIEW, uri).setPackage(pk).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i); ok = true; break } catch (e: Exception) {}
        }
        if (!ok) { say("WhatsApp nahi mila"); return true }
        if (p.send) {
            JarvisAccessibility.setPending("wa_send")
            say(if (JarvisAccessibility.instance == null) "Accessibility ON karo, tabhi send hoga" else "${c.first} ko message bhej raha hoon")
        } else {
            say("${c.first} ki chat me likh diya")
        }
        return true
    }

    // ---------- Phone / Reels / Shorts controls ----------

    private fun noAcc(say: (String) -> Unit): Boolean {
        say("Pehle Accessibility me Jarvis ON karo")
        return true
    }

    private fun mediaKey(ctx: Context, key: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
    }

    private fun controls(ctx: Context, n: List<String>, say: (String) -> Unit): Boolean {
        val s = n.toSet()
        val short = n.size <= 4
        val tiny = n.size <= 3
        val acc = JarvisAccessibility.instance
        val reel = "reel" in s || "reels" in s
        val shorts = "shorts" in s || "short" in s
        val opening = s.any { it in OPEN_W }
        val busy = s.any { it in BUSY_W }

        // Auto scroll: "auto scroll on / off", "auto scroll 5"
        if ("auto" in s && ("scroll" in s || "swipe" in s || reel || shorts)) {
            val a = acc ?: return noAcc(say)
            if (s.any { it == "off" || it == "band" || it == "bandh" || it == "stop" }) {
                a.autoScroll(false, 0); say("Auto scroll band")
            } else {
                val sec = (n.firstNotNullOfOrNull { it.toIntOrNull() } ?: 8).coerceIn(3, 120)
                a.autoScroll(true, sec); say("Auto scroll chalu, har $sec second me")
            }
            return true
        }

        // YouTube Shorts / Instagram Reels kholna
        if (opening && shorts) {
            val i = ctx.packageManager.getLaunchIntentForPackage(JarvisAccessibility.YT)
            if (i == null) { say("YouTube install nahi hai"); return true }
            if (acc != null) JarvisAccessibility.setPending("shorts")
            say(if (acc != null) "YouTube Shorts khol raha hoon" else "YouTube khol raha hoon, Accessibility ON karo to Shorts khud khulega")
            go(ctx, i); return true
        }
        if (opening && reel) {
            val i = ctx.packageManager.getLaunchIntentForPackage(JarvisAccessibility.IG)
            if (i == null) { say("Instagram install nahi hai"); return true }
            if (acc != null) JarvisAccessibility.setPending("reels")
            say(if (acc != null) "Instagram Reels khol raha hoon" else "Instagram khol raha hoon, Accessibility ON karo to Reels khud khulegi")
            go(ctx, i); return true
        }

        // Music (next / previous / pause)
        if (short && s.any { it in MUSIC_W } && s.any { it == "next" || it == "prev" || it == "pause" || it == "ruko" || it == "resume" }) {
            val key = when {
                "next" in s -> KeyEvent.KEYCODE_MEDIA_NEXT
                "prev" in s -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            mediaKey(ctx, key); say("Theek hai"); return true
        }

        // Swipe / scroll
        if (short && ("swipe" in s || "scroll" in s) && !busy) {
            val a = acc ?: return noAcc(say)
            val scroll = "scroll" in s
            if (s.any { it in LEFT_W || it in RIGHT_W }) {
                a.swipeH(s.any { it in LEFT_W }); say("Ho gaya"); return true
            }
            val down = s.any { it in DOWN_W }
            val up = s.any { it in UP_W }
            // Ungli upar = agli reel. "swipe up" / "scroll down" = ungli upar
            val fingerUp = if (scroll) !up else !down
            a.swipe(fingerUp); say("Ho gaya"); return true
        }
        if (short && "next" in s && !busy) { val a = acc ?: return noAcc(say); a.swipe(true); say("Agla"); return true }
        if (short && "prev" in s && !busy) { val a = acc ?: return noAcc(say); a.swipe(false); say("Pichla"); return true }
        if (tiny && !busy && s.any { it == "pause" || it == "ruko" || it == "resume" || it == "tap" }) {
            val a = acc ?: return noAcc(say); a.tapCenter(); say("Ho gaya"); return true
        }
        if (tiny && !busy && "like" in s) {
            val a = acc ?: return noAcc(say)
            say(if (a.like()) "Like kar diya" else "Like button nahi mila"); return true
        }

        // Back / Home / Recents / Screenshot / Notifications
        if (tiny) {
            val act: Pair<Int, String>? = when {
                "back" in s -> Pair(AccessibilityService.GLOBAL_ACTION_BACK, "Peeche")
                "home" in s -> Pair(AccessibilityService.GLOBAL_ACTION_HOME, "Home")
                "recent" in s || "recents" in s -> Pair(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps")
                "notification" in s || "notifications" in s -> Pair(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications")
                "screenshot" in s ->
                    if (Build.VERSION.SDK_INT >= 28) Pair(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Screenshot le liya") else null
                else -> null
            }
            if (act != null) {
                val a = acc ?: return noAcc(say)
                a.performGlobalAction(act.first); say(act.second); return true
            }
        }

        // Volume
        if (n.size <= 6 && ("volume" in s || "mute" in s)) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            when {
                "mute" in s -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                "max" in s || "full" in s ->
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
                s.any { it in INC_W } ->
                    repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                s.any { it in DEC_W } ->
                    repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                else -> return false
            }
            say("Volume theek kar diya"); return true
        }
        return false
    }

    // ---------- Main entry ----------

    fun run(ctx: Context, raw: String, say: (String) -> Unit) {
        var orig = raw
        for ((k, v) in ALIAS) orig = orig.replace(k, v, ignoreCase = true)
        orig = cutWake(orig).trim()
        val t = orig.lowercase()
        if (t.isEmpty()) { say("Ji boliye"); return }
        val o = orig.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val n = t.split(Regex("\\s+")).filter { it.isNotEmpty() }.map { DEV[it] ?: it }

        val has = { ws: List<String> -> ws.any { t.contains(it) } }

        if ("whatsapp" in n && whatsapp(ctx, o, n, say)) return
        if (controls(ctx, n, say)) return

        if (has(listOf("subscribe", "सब्सक्राइब", "सब्स्क्राइब"))) {
            val q = clean(t)
            say("$q ka channel subscribe kar raha hoon")
            JarvisAccessibility.setPending("subscribe")
            yt(ctx, q, true); return
        }
        if (has(listOf("call", "कॉल", "phone", "फोन", "dial"))) {
            val digits = t.filter { it.isDigit() }
            val num = if (digits.length >= 7) digits else findContact(ctx, clean(t))?.second
            if (num == null) { say("Ye contact nahi mila"); return }
            say("Call laga raha hoon")
            go(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))); return
        }
        if (has(listOf("time", "samay", "baje", "टाइम", "समय"))) {
            say("Abhi " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " hue hain"); return
        }
        if (has(listOf("open", "kholo", "khol", "खोलो", "खोल", "start", "chalu")) && !has(listOf("youtube pe", "play"))) {
            val q = clean(t)
            val app = findApp(ctx, if (q.isEmpty()) t else q)
            if (app != null) { say("Khol raha hoon"); go(ctx, app); return }
        }
        if (has(listOf("play", "chala", "चला", "प्ले", "gana", "गाना", "youtube", "song", "video"))) {
            val q = clean(t)
            if (q.isEmpty()) { findApp(ctx, "youtube")?.let { go(ctx, it) }; return }
            say("$q chala raha hoon")
            JarvisAccessibility.setPending("play")
            yt(ctx, q, false); return
        }
        val q = clean(t).ifEmpty { t }
        say("Google pe dhoondh raha hoon")
        go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))))
    }
}
