package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {
    companion object {
        const val YT = "com.google.android.youtube"
        const val IG = "com.instagram.android"
        @Volatile var pending: String? = null
        @Volatile var pendingAt: Long = 0
        @Volatile var instance: JarvisAccessibility? = null
        fun setPending(mode: String) { pending = mode; pendingAt = System.currentTimeMillis() }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var auto: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        autoScroll(false, 0)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        autoScroll(false, 0)
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val mode = pending ?: return
        if (System.currentTimeMillis() - pendingAt > 20000) { pending = null; return }
        val pkg = e?.packageName?.toString() ?: return
        val root = rootInActiveWindow ?: return
        val done = when (mode) {
            "subscribe" -> pkg == YT && trySubscribe(root)
            "play" -> pkg == YT && tryPlay(root)
            "shorts" -> pkg == YT && tryTab(root, "shorts")
            "reels" -> pkg == IG && tryTab(root, "reels")
            "wa_send" -> pkg.startsWith("com.whatsapp") && trySend(root)
            else -> false
        }
        if (done) pending = null
    }

    // ---------- Gestures ----------

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return dispatchGesture(g, null, null)
    }

    /** fingerUp = true: ungli neeche se upar (agli reel / content upar jaata hai) */
    fun swipe(fingerUp: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val a = dm.heightPixels * 0.78f
        val b = dm.heightPixels * 0.25f
        return if (fingerUp) gesture(x, a, x, b, 260) else gesture(x, b, x, a, 260)
    }

    /** toLeft = true: ungli daayen se baayen */
    fun swipeH(toLeft: Boolean): Boolean {
        val dm = resources.displayMetrics
        val y = dm.heightPixels / 2f
        val a = dm.widthPixels * 0.8f
        val b = dm.widthPixels * 0.2f
        return if (toLeft) gesture(a, y, b, y, 250) else gesture(b, y, a, y, 250)
    }

    fun tapCenter(): Boolean {
        val dm = resources.displayMetrics
        return gesture(dm.widthPixels / 2f, dm.heightPixels / 2f, dm.widthPixels / 2f, dm.heightPixels / 2f, 60)
    }

    fun autoScroll(on: Boolean, sec: Int) {
        auto?.let { handler.removeCallbacks(it) }
        auto = null
        if (!on) return
        val r = object : Runnable {
            override fun run() {
                swipe(true)
                handler.postDelayed(this, sec * 1000L)
            }
        }
        auto = r
        handler.postDelayed(r, sec * 1000L)
    }

    // ---------- Button finding ----------

    private fun click(n: AccessibilityNodeInfo?): Boolean {
        var x = n
        while (x != null) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
        }
        return false
    }

    fun like(): Boolean {
        val root = rootInActiveWindow ?: return false
        for (label in listOf("like", "पसंद")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val s = (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase() ?: continue
                if ((s.startsWith("like") && !s.startsWith("liked")) || s.startsWith("पसंद")) {
                    if (click(n)) return true
                }
            }
        }
        return false
    }

    private fun trySubscribe(root: AccessibilityNodeInfo): Boolean {
        for (label in listOf("Subscribe", "सब्सक्राइब करें")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val s = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
                if (s.equals("Subscribe", true) || s == "सब्सक्राइब करें" || s.startsWith("Subscribe to", true)) {
                    if (click(n)) return true
                }
            }
        }
        return false
    }

    private fun tryPlay(root: AccessibilityNodeInfo): Boolean {
        val hits = root.findAccessibilityNodeInfosByText("Play video")
        for (n in hits) if (click(n)) return true
        return false
    }

    /** Niche wali bar ka "Shorts" / "Reels" tab dabata hai */
    private fun tryTab(root: AccessibilityNodeInfo, label: String): Boolean {
        val h = resources.displayMetrics.heightPixels
        for (n in root.findAccessibilityNodeInfosByText(label)) {
            val s = (n.contentDescription ?: n.text)?.toString()?.lowercase() ?: continue
            if (!s.contains(label)) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top > h * 0.8 && click(n)) return true
        }
        return false
    }

    /** WhatsApp ka Send button dabata hai */
    private fun trySend(root: AccessibilityNodeInfo): Boolean {
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            for (n in root.findAccessibilityNodeInfosByViewId(id)) if (click(n)) return true
        }
        for (label in listOf("Send", "भेजें", "भेजे")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                val s = (n.contentDescription ?: n.text)?.toString()?.trim() ?: continue
                if (s.equals("Send", true) || s == "भेजें" || s == "भेजे") {
                    if (click(n)) return true
                }
            }
        }
        return false
    }
}
