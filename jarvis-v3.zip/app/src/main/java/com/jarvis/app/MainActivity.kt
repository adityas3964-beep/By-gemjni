package com.jarvis.app

import android.Manifest
import android.animation.Keyframe
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private val GREEN = Color.parseColor("#00FF41")
private val DIM = Color.parseColor("#0B6B26")
private val RED = Color.parseColor("#FF2A2A")
private val BG = Color.parseColor("#020702")
private val MONO: Typeface = Typeface.MONOSPACE

private const val HELP = """WHATSAPP
> whatsapp pe Rahul ko hello bhej
> Rahul ki chat me I don't know likh aur send kar de
  (send/bhej bolega tabhi bhejega, warna sirf likh dega)

REELS / SHORTS
> youtube shorts khol
> instagram reels khol
> next / agli reel   (swipe up)
> previous / pichli  (swipe down)
> like, pause, ruko
> auto scroll on / auto scroll 5 / auto scroll off

PHONE
> swipe up/down/left/right
> scroll down / scroll up
> back, home, recents
> screenshot, notifications
> volume up / down / mute

YOUTUBE / BAAKI
> <gaana> chala
> <channel> subscribe
> Rahul ko call
> time kya hai
> <app> khol
"""

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var heart: HeartView
    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var logView: TextView
    private var anim: ObjectAnimator? = null
    private var isOn = false
    private var miss = 0
    private var cursor = true
    private var loop: Runnable? = null
    private var uname = "Aditya"
    private val lines = ArrayList<String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create(MONO, Typeface.BOLD) else MONO
        }

    private fun hbtn(t: String, f: (Button) -> Unit): Button = Button(this).apply {
        text = t
        typeface = MONO
        setTextColor(GREEN)
        textSize = 12f
        isAllCaps = false
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), DIM)
            cornerRadius = dp(4).toFloat()
        }
        setOnClickListener { f(this) }
    }

    private fun row(parent: LinearLayout, a: Button, b: Button) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = {
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
        }
        r.addView(a, lp())
        r.addView(b, lp())
        parent.addView(r)
    }

    private fun log(msg: String) {
        lines.add("> $msg")
        while (lines.size > 6) lines.removeAt(0)
        logView.text = lines.joinToString("\n")
    }

    private fun beat(v: View): ObjectAnimator {
        fun kf() = arrayOf(
            Keyframe.ofFloat(0f, 1f), Keyframe.ofFloat(0.12f, 1.16f), Keyframe.ofFloat(0.24f, 1f),
            Keyframe.ofFloat(0.36f, 1.10f), Keyframe.ofFloat(0.5f, 1f), Keyframe.ofFloat(1f, 1f)
        )
        val sx = PropertyValuesHolder.ofKeyframe(View.SCALE_X, *kf())
        val sy = PropertyValuesHolder.ofKeyframe(View.SCALE_Y, *kf())
        return ObjectAnimator.ofPropertyValuesHolder(v, sx, sy).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
        }
    }

    private fun setUi(on: Boolean, announce: Boolean) {
        isOn = on
        heart.on = on
        anim?.cancel()
        anim = null
        heart.scaleX = 1f
        heart.scaleY = 1f
        if (on) {
            anim = beat(heart).also { it.start() }
            status.text = "SYSTEM ONLINE\n[ SAY \"JARVIS\" ]"
            status.setTextColor(GREEN)
            if (announce) log("heartbeat detected. JARVIS ONLINE")
        } else {
            status.text = "SYSTEM OFFLINE\n[ TAP HEART TO ACTIVATE ]"
            status.setTextColor(RED)
            if (announce) log("flatline. JARVIS OFFLINE")
        }
    }

    private fun askPermissions() {
        requestPermissions(arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS), 1)
    }

    private fun help() {
        val body = tv(HELP, 12f, GREEN).apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val sv = ScrollView(this).apply { setBackgroundColor(BG); addView(body) }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("> COMMANDS")
            .setView(sv)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val p = getSharedPreferences("jarvis", MODE_PRIVATE)
        uname = p.getString("name", "Aditya")?.trim() ?: "Aditya"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(30), dp(16), dp(16))
        }
        val sv = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(BG)
            addView(root)
        }
        setContentView(sv)

        // ---- Top: admin ----
        title = tv("", 22f, GREEN, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
            setShadowLayer(14f, 0f, 0f, GREEN)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(tv("J.A.R.V.I.S  //  VOICE CONTROL", 11f, DIM).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        root.addView(View(this).apply { setBackgroundColor(DIM) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12) })

        // ---- Middle: beating heart ----
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        heart = HeartView(this)
        heart.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (JarvisService.running) {
                stopService(Intent(this, JarvisService::class.java))
                miss = 0
                setUi(false, true)
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Pehle permissions do, phir heart dabao", Toast.LENGTH_LONG).show()
                log("mic permission missing")
                askPermissions()
            } else {
                startForegroundService(Intent(this, JarvisService::class.java))
                miss = 0
                setUi(true, true)
            }
        }
        mid.addView(heart, LinearLayout.LayoutParams(dp(230), dp(230)))
        status = tv("", 13f, RED, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        mid.addView(status, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- Terminal log ----
        logView = tv("", 11f, GREEN).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            minHeight = dp(110)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#041004"))
                setStroke(dp(1), DIM)
            }
        }
        root.addView(logView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // ---- User name ----
        root.addView(tv("> USER NAME  (Jarvis isi naam se bulayega)", 11f, DIM),
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        val nameBox = EditText(this).apply {
            setText(uname)
            hint = "apna naam likho"
            setHintTextColor(DIM)
            setTextColor(GREEN)
            typeface = MONO
            textSize = 15f
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#041004"))
                setStroke(dp(1), GREEN)
                cornerRadius = dp(4).toFloat()
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    uname = s?.toString()?.trim() ?: ""
                    p.edit().putString("name", uname).apply()
                }
            })
        }
        root.addView(nameBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // ---- Setup buttons ----
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var langBtn: Button
        fun updLang() {
            langBtn.text = "[ LANG: " + (if (p.getString("lang", "hi-IN") == "hi-IN") "HINDI" else "ENGLISH") + " ]"
        }
        langBtn = hbtn("") {
            val nl = if (p.getString("lang", "hi-IN") == "hi-IN") "en-IN" else "hi-IN"
            p.edit().putString("lang", nl).apply()
            updLang()
            log("speech language: $nl")
        }
        updLang()
        row(grid, hbtn("[1] PERMISSIONS") { askPermissions() },
            hbtn("[2] OVERLAY") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
        row(grid, hbtn("[3] ACCESSIBILITY") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            hbtn("[4] BATTERY") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        row(grid, langBtn, hbtn("[?] COMMANDS") { help() })
        root.addView(grid)

        // ---- Boot sequence ----
        setUi(JarvisService.running, false)
        val boot = listOf(
            "boot sequence initiated...",
            "user: " + (if (uname.isEmpty()) "BOSS" else uname.uppercase()) + " [ADMIN]",
            "wake-word engine: VOSK (offline)",
            "modules: whatsapp / reels / shorts / gestures",
            if (JarvisService.running) "JARVIS already online" else "awaiting heartbeat..."
        )
        boot.forEachIndexed { i, m -> h.postDelayed({ log(m) }, 350L * (i + 1)) }
    }

    override fun onResume() {
        super.onResume()
        val r = object : Runnable {
            override fun run() {
                cursor = !cursor
                title.text = "ADMIN :: " + (if (uname.isEmpty()) "BOSS" else uname.uppercase()) + if (cursor) "\u2588" else " "
                val running = JarvisService.running
                if (running && !isOn) { miss = 0; setUi(true, true) }
                else if (!running && isOn) {
                    miss++
                    if (miss >= 4) { miss = 0; setUi(false, true) }
                } else miss = 0
                h.postDelayed(this, 500)
            }
        }
        loop = r
        h.post(r)
    }

    override fun onPause() {
        super.onPause()
        loop?.let { h.removeCallbacks(it) }
        loop = null
    }

    override fun onDestroy() {
        anim?.cancel()
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
