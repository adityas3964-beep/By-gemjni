package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Neon heart + ECG line. on = green, off = red. */
class HeartView(ctx: Context) : View(ctx) {
    var on: Boolean = false
        set(v) { field = v; invalidate() }

    private val heart = Path()
    private val pulse = Path()
    private val heartPx = Path()
    private val pulsePx = Path()
    private val density = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        heart.moveTo(12f, 21.35f)
        heart.lineTo(10.55f, 20.03f)
        heart.cubicTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f)
        heart.cubicTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f)
        heart.cubicTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f)
        heart.cubicTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f)
        heart.cubicTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f)
        heart.cubicTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f)
        heart.close()

        pulse.moveTo(4f, 12.5f)
        pulse.lineTo(8.5f, 12.5f)
        pulse.lineTo(10f, 9f)
        pulse.lineTo(12f, 16.5f)
        pulse.lineTo(13.8f, 10.5f)
        pulse.lineTo(15f, 12.5f)
        pulse.lineTo(20f, 12.5f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = minOf(w, h) / 24f * 0.92f
        val m = Matrix()
        m.setScale(s, s)
        m.postTranslate(w / 2f - 12f * s, h / 2f - 12.2f * s)
        heart.transform(m, heartPx)
        pulse.transform(m, pulsePx)
    }

    override fun onDraw(c: Canvas) {
        val col = if (on) Color.parseColor("#00FF41") else Color.parseColor("#FF2A2A")
        fill.color = Color.argb(if (on) 60 else 30, Color.red(col), Color.green(col), Color.blue(col))
        c.drawPath(heartPx, fill)

        stroke.color = col
        stroke.strokeWidth = 3f * density
        stroke.setShadowLayer((if (on) 18f else 8f) * density, 0f, 0f, col)
        c.drawPath(heartPx, stroke)

        stroke.color = if (on) Color.WHITE else Color.parseColor("#7A1414")
        stroke.strokeWidth = 2f * density
        stroke.setShadowLayer((if (on) 8f else 0f) * density, 0f, 0f, col)
        c.drawPath(pulsePx, stroke)
    }
}
